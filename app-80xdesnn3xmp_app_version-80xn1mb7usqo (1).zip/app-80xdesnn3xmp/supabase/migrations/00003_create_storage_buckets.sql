/*
# Create Storage Buckets for Avatars and Chat Files

## 1. Storage Buckets
- `app-80xdesnn3xmp_avatars` - For user profile pictures
- `app-80xdesnn3xmp_chat_files` - For shared documents and images in chats

## 2. Security Policies
- All authenticated users can upload avatars
- All authenticated users can view avatars
- All authenticated users can upload chat files
- All authenticated users can view chat files
*/

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
  ('app-80xdesnn3xmp_avatars', 'app-80xdesnn3xmp_avatars', true, 1048576, ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif']),
  ('app-80xdesnn3xmp_chat_files', 'app-80xdesnn3xmp_chat_files', true, 1048576, ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain'])
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Authenticated users can upload avatars"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'app-80xdesnn3xmp_avatars');

CREATE POLICY "Anyone can view avatars"
ON storage.objects FOR SELECT
USING (bucket_id = 'app-80xdesnn3xmp_avatars');

CREATE POLICY "Users can update their own avatars"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'app-80xdesnn3xmp_avatars');

CREATE POLICY "Users can delete their own avatars"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'app-80xdesnn3xmp_avatars');

CREATE POLICY "Authenticated users can upload chat files"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'app-80xdesnn3xmp_chat_files');

CREATE POLICY "Anyone can view chat files"
ON storage.objects FOR SELECT
USING (bucket_id = 'app-80xdesnn3xmp_chat_files');

CREATE POLICY "Users can delete their own chat files"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'app-80xdesnn3xmp_chat_files');