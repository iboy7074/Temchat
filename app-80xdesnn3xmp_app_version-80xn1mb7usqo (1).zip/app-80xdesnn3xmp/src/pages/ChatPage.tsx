import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { chatRoomsApi, messagesApi, profilesApi } from '@/db/api';
import type { MessageWithSender, Profile, ChatRoom } from '@/types/types';
import { ChatSidebar } from '@/components/chat/ChatSidebar';
import { MessageBubble } from '@/components/chat/MessageBubble';
import { ChatInput } from '@/components/chat/ChatInput';
import { UserAvatar } from '@/components/chat/UserAvatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Users, Settings, Info, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';

export default function ChatPage() {
  const { user } = useAuth();
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  const [messages, setMessages] = useState<MessageWithSender[]>([]);
  const [roomMembers, setRoomMembers] = useState<Profile[]>([]);
  const [currentRoom, setCurrentRoom] = useState<ChatRoom | null>(null);
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const subscriptionRef = useRef<any>(null);

  useEffect(() => {
    if (selectedRoomId && user) {
      loadRoomData();
      subscribeToMessages();
      chatRoomsApi.updateLastRead(selectedRoomId, user.id).catch(console.error);
    }

    return () => {
      if (subscriptionRef.current) {
        subscriptionRef.current.unsubscribe();
      }
    };
  }, [selectedRoomId, user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadRoomData = async () => {
    if (!selectedRoomId) return;
    
    setLoading(true);
    try {
      const [messagesData, membersData] = await Promise.all([
        messagesApi.getRoomMessages(selectedRoomId),
        chatRoomsApi.getRoomMembers(selectedRoomId)
      ]);

      const messagesWithSenders = await Promise.all(
        messagesData.map(async (msg) => {
          if (msg.sender_id) {
            const sender = await profilesApi.getProfile(msg.sender_id);
            return { ...msg, sender };
          }
          return msg;
        })
      );

      setMessages(messagesWithSenders);
      setRoomMembers(membersData);

      const rooms = await chatRoomsApi.getUserRooms(user!.id);
      const room = rooms.find(r => r.id === selectedRoomId);
      setCurrentRoom(room || null);
    } catch (error) {
      console.error('Error loading room data:', error);
      toast.error('Failed to load messages');
    } finally {
      setLoading(false);
    }
  };

  const subscribeToMessages = () => {
    if (!selectedRoomId) return;

    subscriptionRef.current = messagesApi.subscribeToRoomMessages(
      selectedRoomId,
      async (newMessage) => {
        if (newMessage.sender_id) {
          const sender = await profilesApi.getProfile(newMessage.sender_id);
          setMessages(prev => [...prev, { ...newMessage, sender }]);
        } else {
          setMessages(prev => [...prev, newMessage]);
        }
      }
    );
  };

  const handleSendMessage = async (
    content: string,
    type: 'text' | 'image' | 'file' = 'text',
    fileUrl?: string,
    fileName?: string
  ) => {
    if (!selectedRoomId || !user) return;

    try {
      await messagesApi.sendMessage(selectedRoomId, user.id, content, type, fileUrl, fileName);
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
    }
  };

  const getRoomDisplayName = () => {
    if (!currentRoom) return 'Select a chat';
    if (currentRoom.type === 'group') {
      return currentRoom.name || 'Unnamed Group';
    }
    const otherMember = roomMembers.find(m => m.id !== user?.id);
    return otherMember?.username || 'Unknown User';
  };

  const getRoomAvatar = () => {
    if (!currentRoom || currentRoom.type === 'group') return null;
    return roomMembers.find(m => m.id !== user?.id);
  };

  return (
    <div className="flex h-screen bg-background">
      <ChatSidebar selectedRoomId={selectedRoomId} onSelectRoom={setSelectedRoomId} />

      <div className="flex-1 flex flex-col">
        {selectedRoomId ? (
          <>
            <div className="h-16 border-b border-border bg-card px-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {currentRoom?.type === 'group' ? (
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                    <Users className="w-5 h-5 text-primary-foreground" />
                  </div>
                ) : (
                  <UserAvatar
                    username={getRoomAvatar()?.username || 'Unknown'}
                    avatarUrl={getRoomAvatar()?.avatar_url}
                    status={getRoomAvatar()?.status}
                    showStatus
                  />
                )}
                <div>
                  <h2 className="font-semibold">{getRoomDisplayName()}</h2>
                  <p className="text-xs text-muted-foreground">
                    {currentRoom?.type === 'group' 
                      ? `${roomMembers.length} members` 
                      : getRoomAvatar()?.status}
                  </p>
                </div>
              </div>

              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Info className="w-5 h-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent>
                  <SheetHeader>
                    <SheetTitle>Chat Info</SheetTitle>
                    <SheetDescription>
                      {currentRoom?.type === 'group' ? 'Group members' : 'Chat details'}
                    </SheetDescription>
                  </SheetHeader>
                  <div className="mt-6 space-y-4">
                    <div className="text-center">
                      {currentRoom?.type === 'group' ? (
                        <div className="w-20 h-20 rounded-full bg-primary flex items-center justify-center mx-auto mb-3">
                          <Users className="w-10 h-10 text-primary-foreground" />
                        </div>
                      ) : (
                        <div className="flex justify-center mb-3">
                          <UserAvatar
                            username={getRoomAvatar()?.username || 'Unknown'}
                            avatarUrl={getRoomAvatar()?.avatar_url}
                            size="lg"
                          />
                        </div>
                      )}
                      <h3 className="font-semibold text-lg">{getRoomDisplayName()}</h3>
                    </div>

                    <Separator />

                    <div>
                      <h4 className="font-medium mb-3">Members ({roomMembers.length})</h4>
                      <div className="space-y-2">
                        {roomMembers.map(member => (
                          <div key={member.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted">
                            <UserAvatar
                              username={member.username}
                              avatarUrl={member.avatar_url}
                              status={member.status}
                              showStatus
                              size="sm"
                            />
                            <div className="flex-1">
                              <p className="font-medium text-sm">{member.username}</p>
                              <p className="text-xs text-muted-foreground">{member.status}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>

            <ScrollArea className="flex-1 p-4">
              {loading ? (
                <div className="flex items-center justify-center h-full">
                  <p className="text-muted-foreground">Loading messages...</p>
                </div>
              ) : messages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground">No messages yet</p>
                    <p className="text-sm text-muted-foreground">Start the conversation!</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {messages.map(message => (
                    <MessageBubble
                      key={message.id}
                      message={message}
                      isOwn={message.sender_id === user?.id}
                    />
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </ScrollArea>

            <ChatInput onSendMessage={handleSendMessage} disabled={loading} />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <MessageSquare className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Welcome to TeamChat</h3>
              <p className="text-muted-foreground">Select a chat to start messaging</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
