import { supabase } from './supabase';
import type { Profile, ChatRoom, Message, RoomMember, ChatRoomWithMembers, MessageWithSender } from '@/types/types';

export const profilesApi = {
  async getProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getAllProfiles(): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('username', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', userId)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async updateStatus(userId: string, status: string): Promise<void> {
    const { error } = await supabase
      .from('profiles')
      .update({ status })
      .eq('id', userId);
    
    if (error) throw error;
  },

  async searchUsers(query: string): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .ilike('username', `%${query}%`)
      .order('username', { ascending: true })
      .limit(10);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  }
};

export const chatRoomsApi = {
  async getUserRooms(userId: string): Promise<ChatRoomWithMembers[]> {
    const { data, error } = await supabase
      .from('room_members')
      .select(`
        room_id,
        chat_rooms (
          id,
          name,
          type,
          created_by,
          created_at,
          updated_at
        )
      `)
      .eq('user_id', userId)
      .order('room_id', { ascending: true });
    
    if (error) throw error;
    
    const rooms = Array.isArray(data) ? data : [];
    return rooms.map((item: any) => item.chat_rooms).filter(Boolean);
  },

  async createDirectRoom(userId: string, otherUserId: string): Promise<ChatRoom | null> {
    const existingRoom = await this.findDirectRoom(userId, otherUserId);
    if (existingRoom) return existingRoom;

    const { data: room, error: roomError } = await supabase
      .from('chat_rooms')
      .insert({
        type: 'direct',
        created_by: userId
      })
      .select()
      .maybeSingle();
    
    if (roomError) throw roomError;
    if (!room) return null;

    const { error: membersError } = await supabase
      .from('room_members')
      .insert([
        { room_id: room.id, user_id: userId },
        { room_id: room.id, user_id: otherUserId }
      ]);
    
    if (membersError) throw membersError;
    return room;
  },

  async findDirectRoom(userId: string, otherUserId: string): Promise<ChatRoom | null> {
    const { data: userRooms, error: userRoomsError } = await supabase
      .from('room_members')
      .select('room_id')
      .eq('user_id', userId);
    
    if (userRoomsError) throw userRoomsError;
    
    const roomIds = (userRooms || []).map(r => r.room_id);
    if (roomIds.length === 0) return null;

    const { data: otherUserRooms, error: otherUserRoomsError } = await supabase
      .from('room_members')
      .select('room_id')
      .eq('user_id', otherUserId)
      .in('room_id', roomIds);
    
    if (otherUserRoomsError) throw otherUserRoomsError;
    
    const commonRoomIds = (otherUserRooms || []).map(r => r.room_id);
    if (commonRoomIds.length === 0) return null;

    const { data: room, error: roomError } = await supabase
      .from('chat_rooms')
      .select('*')
      .eq('type', 'direct')
      .in('id', commonRoomIds)
      .order('id', { ascending: true })
      .limit(1)
      .maybeSingle();
    
    if (roomError) throw roomError;
    return room;
  },

  async createGroupRoom(userId: string, name: string, memberIds: string[]): Promise<ChatRoom | null> {
    const { data: room, error: roomError } = await supabase
      .from('chat_rooms')
      .insert({
        name,
        type: 'group',
        created_by: userId
      })
      .select()
      .maybeSingle();
    
    if (roomError) throw roomError;
    if (!room) return null;

    const allMemberIds = Array.from(new Set([userId, ...memberIds]));
    const { error: membersError } = await supabase
      .from('room_members')
      .insert(allMemberIds.map(id => ({ room_id: room.id, user_id: id })));
    
    if (membersError) throw membersError;
    return room;
  },

  async getRoomMembers(roomId: string): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('room_members')
      .select(`
        user_id,
        profiles (
          id,
          username,
          email,
          avatar_url,
          status,
          bio,
          role,
          created_at,
          updated_at
        )
      `)
      .eq('room_id', roomId)
      .order('user_id', { ascending: true });
    
    if (error) throw error;
    
    const members = Array.isArray(data) ? data : [];
    return members.map((item: any) => item.profiles).filter(Boolean);
  },

  async addRoomMember(roomId: string, userId: string): Promise<void> {
    const { error } = await supabase
      .from('room_members')
      .insert({ room_id: roomId, user_id: userId });
    
    if (error) throw error;
  },

  async removeRoomMember(roomId: string, userId: string): Promise<void> {
    const { error } = await supabase
      .from('room_members')
      .delete()
      .eq('room_id', roomId)
      .eq('user_id', userId);
    
    if (error) throw error;
  },

  async updateLastRead(roomId: string, userId: string): Promise<void> {
    const { error } = await supabase
      .from('room_members')
      .update({ last_read_at: new Date().toISOString() })
      .eq('room_id', roomId)
      .eq('user_id', userId);
    
    if (error) throw error;
  }
};

export const messagesApi = {
  async getRoomMessages(roomId: string, limit = 50): Promise<MessageWithSender[]> {
    const { data, error } = await supabase
      .from('messages')
      .select(`
        *,
        profiles:sender_id (
          id,
          username,
          avatar_url,
          status
        )
      `)
      .eq('room_id', roomId)
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    
    const messages = Array.isArray(data) ? data : [];
    return messages.map((msg: any) => ({
      ...msg,
      sender: msg.profiles
    })).reverse();
  },

  async sendMessage(
    roomId: string,
    senderId: string,
    content: string,
    type: 'text' | 'image' | 'file' = 'text',
    fileUrl?: string,
    fileName?: string
  ): Promise<Message | null> {
    const { data, error } = await supabase
      .from('messages')
      .insert({
        room_id: roomId,
        sender_id: senderId,
        content,
        type,
        file_url: fileUrl || null,
        file_name: fileName || null
      })
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async createMention(messageId: string, userId: string): Promise<void> {
    const { error } = await supabase
      .from('mentions')
      .insert({ message_id: messageId, user_id: userId });
    
    if (error) throw error;
  },

  subscribeToRoomMessages(roomId: string, callback: (message: Message) => void) {
    return supabase
      .channel(`room:${roomId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `room_id=eq.${roomId}`
        },
        (payload) => {
          callback(payload.new as Message);
        }
      )
      .subscribe();
  }
};

export const storageApi = {
  async uploadAvatar(userId: string, file: File): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}_${Date.now()}.${fileExt}`;
    
    const { error: uploadError } = await supabase.storage
      .from('app-80xdesnn3xmp_avatars')
      .upload(fileName, file, { upsert: true });
    
    if (uploadError) throw uploadError;

    const { data } = supabase.storage
      .from('app-80xdesnn3xmp_avatars')
      .getPublicUrl(fileName);
    
    return data.publicUrl;
  },

  async uploadChatFile(file: File): Promise<{ url: string; name: string }> {
    const timestamp = Date.now();
    const sanitizedName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const fileName = `${timestamp}_${sanitizedName}`;
    
    const { error: uploadError } = await supabase.storage
      .from('app-80xdesnn3xmp_chat_files')
      .upload(fileName, file);
    
    if (uploadError) throw uploadError;

    const { data } = supabase.storage
      .from('app-80xdesnn3xmp_chat_files')
      .getPublicUrl(fileName);
    
    return { url: data.publicUrl, name: file.name };
  }
};
