import ChatPage from './pages/ChatPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ProfilePage from './pages/ProfilePage';
import AdminPage from './pages/AdminPage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  requireAuth?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Chat',
    path: '/',
    element: <ChatPage />,
    requireAuth: true
  },
  {
    name: 'Profile',
    path: '/profile',
    element: <ProfilePage />,
    visible: false,
    requireAuth: true
  },
  {
    name: 'Admin',
    path: '/admin',
    element: <AdminPage />,
    visible: false,
    requireAuth: true
  },
  {
    name: 'Login',
    path: '/login',
    element: <LoginPage />,
    visible: false
  },
  {
    name: 'Register',
    path: '/register',
    element: <RegisterPage />,
    visible: false
  }
];

export default routes;
