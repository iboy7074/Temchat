import { UserAvatar } from './UserAvatar';
import type { MessageWithSender } from '@/types/types';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { FileText, Image as ImageIcon } from 'lucide-react';

interface MessageBubbleProps {
  message: MessageWithSender;
  isOwn: boolean;
}

export function MessageBubble({ message, isOwn }: MessageBubbleProps) {
  const formatTime = (dateString: string) => {
    return format(new Date(dateString), 'HH:mm');
  };

  const renderMessageContent = () => {
    if (message.type === 'image' && message.file_url) {
      return (
        <div className="space-y-2">
          <img 
            src={message.file_url} 
            alt={message.file_name || 'Image'} 
            className="max-w-xs rounded-lg"
          />
          {message.content && <p className="text-sm">{message.content}</p>}
        </div>
      );
    }

    if (message.type === 'file' && message.file_url) {
      return (
        <div className="space-y-2">
          <a 
            href={message.file_url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-2 p-2 rounded bg-muted hover:bg-muted/80 transition-colors"
          >
            <FileText className="w-5 h-5" />
            <span className="text-sm">{message.file_name || 'File'}</span>
          </a>
          {message.content && <p className="text-sm">{message.content}</p>}
        </div>
      );
    }

    return <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>;
  };

  return (
    <div className={cn('flex gap-3 max-w-2xl', isOwn ? 'ml-auto flex-row-reverse' : 'mr-auto')}>
      {!isOwn && (
        <UserAvatar
          username={message.sender?.username || 'Unknown'}
          avatarUrl={message.sender?.avatar_url}
          size="sm"
        />
      )}
      <div className={cn('flex flex-col', isOwn ? 'items-end' : 'items-start')}>
        {!isOwn && (
          <span className="text-xs font-medium text-muted-foreground mb-1">
            {message.sender?.username || 'Unknown'}
          </span>
        )}
        <div
          className={cn(
            'rounded-lg px-4 py-2 shadow-sm',
            isOwn 
              ? 'bg-primary text-primary-foreground' 
              : 'bg-card border border-border'
          )}
        >
          {renderMessageContent()}
        </div>
        <span className="text-xs text-muted-foreground mt-1">
          {formatTime(message.created_at)}
        </span>
      </div>
    </div>
  );
}
