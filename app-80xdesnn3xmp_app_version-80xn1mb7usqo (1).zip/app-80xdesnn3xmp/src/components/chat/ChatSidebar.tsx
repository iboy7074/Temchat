import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { chatRoomsApi, profilesApi } from '@/db/api';
import type { ChatRoomWithMembers, Profile } from '@/types/types';
import { UserAvatar } from './UserAvatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Search, Users, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface ChatSidebarProps {
  selectedRoomId: string | null;
  onSelectRoom: (roomId: string) => void;
}

export function ChatSidebar({ selectedRoomId, onSelectRoom }: ChatSidebarProps) {
  const { user } = useAuth();
  const [rooms, setRooms] = useState<ChatRoomWithMembers[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [showNewChatDialog, setShowNewChatDialog] = useState(false);
  const [allUsers, setAllUsers] = useState<Profile[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [groupName, setGroupName] = useState('');
  const [chatType, setChatType] = useState<'direct' | 'group'>('direct');

  useEffect(() => {
    if (user) {
      loadRooms();
    }
  }, [user]);

  const loadRooms = async () => {
    if (!user) return;
    try {
      const data = await chatRoomsApi.getUserRooms(user.id);
      
      const roomsWithMembers = await Promise.all(
        data.map(async (room) => {
          const members = await chatRoomsApi.getRoomMembers(room.id);
          return { ...room, members };
        })
      );
      
      setRooms(roomsWithMembers);
    } catch (error) {
      console.error('Error loading rooms:', error);
      toast.error('Failed to load chats');
    } finally {
      setLoading(false);
    }
  };

  const loadUsers = async () => {
    try {
      const users = await profilesApi.getAllProfiles();
      setAllUsers(users.filter(u => u.id !== user?.id));
    } catch (error) {
      console.error('Error loading users:', error);
      toast.error('Failed to load users');
    }
  };

  const handleOpenNewChat = () => {
    setShowNewChatDialog(true);
    loadUsers();
  };

  const handleCreateChat = async () => {
    if (!user) return;

    try {
      if (chatType === 'direct') {
        if (selectedUsers.length !== 1) {
          toast.error('Please select one user for direct chat');
          return;
        }
        const room = await chatRoomsApi.createDirectRoom(user.id, selectedUsers[0]);
        if (room) {
          await loadRooms();
          onSelectRoom(room.id);
          setShowNewChatDialog(false);
          setSelectedUsers([]);
        }
      } else {
        if (selectedUsers.length === 0) {
          toast.error('Please select at least one member');
          return;
        }
        if (!groupName.trim()) {
          toast.error('Please enter a group name');
          return;
        }
        const room = await chatRoomsApi.createGroupRoom(user.id, groupName, selectedUsers);
        if (room) {
          await loadRooms();
          onSelectRoom(room.id);
          setShowNewChatDialog(false);
          setSelectedUsers([]);
          setGroupName('');
        }
      }
      toast.success('Chat created successfully');
    } catch (error) {
      console.error('Error creating chat:', error);
      toast.error('Failed to create chat');
    }
  };

  const getRoomDisplayName = (room: ChatRoomWithMembers) => {
    if (room.type === 'group') {
      return room.name || 'Unnamed Group';
    }
    const otherMember = room.members?.find(m => m.id !== user?.id);
    return otherMember?.username || 'Unknown User';
  };

  const getRoomAvatar = (room: ChatRoomWithMembers) => {
    if (room.type === 'group') {
      return null;
    }
    const otherMember = room.members?.find(m => m.id !== user?.id);
    return otherMember;
  };

  const filteredRooms = rooms.filter(room => {
    const displayName = getRoomDisplayName(room).toLowerCase();
    return displayName.includes(searchQuery.toLowerCase());
  });

  return (
    <div className="w-full xl:w-80 border-r border-border bg-card flex flex-col h-full">
      <div className="p-4 border-b border-border space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Chats</h2>
          <Dialog open={showNewChatDialog} onOpenChange={setShowNewChatDialog}>
            <DialogTrigger asChild>
              <Button size="sm" onClick={handleOpenNewChat}>
                <Plus className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>New Chat</DialogTitle>
                <DialogDescription>Start a new conversation</DialogDescription>
              </DialogHeader>
              <Tabs value={chatType} onValueChange={(v) => setChatType(v as 'direct' | 'group')}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="direct">
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Direct
                  </TabsTrigger>
                  <TabsTrigger value="group">
                    <Users className="w-4 h-4 mr-2" />
                    Group
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="direct" className="space-y-4">
                  <div className="space-y-2">
                    <Label>Select a user</Label>
                    <ScrollArea className="h-64 border rounded-md p-2">
                      {allUsers.map(user => (
                        <div
                          key={user.id}
                          className={cn(
                            'flex items-center space-x-3 p-2 rounded-md cursor-pointer hover:bg-muted',
                            selectedUsers.includes(user.id) && 'bg-muted'
                          )}
                          onClick={() => setSelectedUsers([user.id])}
                        >
                          <UserAvatar username={user.username} avatarUrl={user.avatar_url} status={user.status} showStatus />
                          <div className="flex-1">
                            <p className="font-medium">{user.username}</p>
                            <p className="text-xs text-muted-foreground">{user.status}</p>
                          </div>
                        </div>
                      ))}
                    </ScrollArea>
                  </div>
                </TabsContent>
                <TabsContent value="group" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="groupName">Group Name</Label>
                    <Input
                      id="groupName"
                      placeholder="Enter group name"
                      value={groupName}
                      onChange={(e) => setGroupName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Select members</Label>
                    <ScrollArea className="h-48 border rounded-md p-2">
                      {allUsers.map(user => (
                        <div key={user.id} className="flex items-center space-x-3 p-2">
                          <Checkbox
                            checked={selectedUsers.includes(user.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedUsers([...selectedUsers, user.id]);
                              } else {
                                setSelectedUsers(selectedUsers.filter(id => id !== user.id));
                              }
                            }}
                          />
                          <UserAvatar username={user.username} avatarUrl={user.avatar_url} size="sm" />
                          <span className="text-sm">{user.username}</span>
                        </div>
                      ))}
                    </ScrollArea>
                  </div>
                </TabsContent>
              </Tabs>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowNewChatDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateChat}>
                  Create Chat
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search chats..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <ScrollArea className="flex-1">
        {loading ? (
          <div className="p-4 text-center text-muted-foreground">Loading chats...</div>
        ) : filteredRooms.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground">
            {searchQuery ? 'No chats found' : 'No chats yet. Start a new conversation!'}
          </div>
        ) : (
          <div className="p-2 space-y-1">
            {filteredRooms.map(room => {
              const otherMember = getRoomAvatar(room);
              return (
                <button
                  key={room.id}
                  onClick={() => onSelectRoom(room.id)}
                  className={cn(
                    'w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-muted transition-colors text-left',
                    selectedRoomId === room.id && 'bg-muted'
                  )}
                >
                  {room.type === 'group' ? (
                    <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                      <Users className="w-5 h-5 text-primary-foreground" />
                    </div>
                  ) : (
                    <UserAvatar
                      username={otherMember?.username || 'Unknown'}
                      avatarUrl={otherMember?.avatar_url}
                      status={otherMember?.status}
                      showStatus
                    />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{getRoomDisplayName(room)}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {room.type === 'group' ? `${room.members?.length || 0} members` : otherMember?.status}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
