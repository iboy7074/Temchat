import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';

interface UserAvatarProps {
  username: string;
  avatarUrl?: string | null;
  status?: string;
  size?: 'sm' | 'md' | 'lg';
  showStatus?: boolean;
  className?: string;
}

export function UserAvatar({ 
  username, 
  avatarUrl, 
  status = 'offline', 
  size = 'md',
  showStatus = false,
  className 
}: UserAvatarProps) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12'
  };

  const statusSizeClasses = {
    sm: 'w-2 h-2',
    md: 'w-2.5 h-2.5',
    lg: 'w-3 h-3'
  };

  const getInitials = (name: string) => {
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <div className={cn('relative', className)}>
      <Avatar className={sizeClasses[size]}>
        <AvatarImage src={avatarUrl || undefined} alt={username} />
        <AvatarFallback className="bg-primary text-primary-foreground">
          {getInitials(username)}
        </AvatarFallback>
      </Avatar>
      {showStatus && (
        <span 
          className={cn(
            'absolute bottom-0 right-0 rounded-full border-2 border-card',
            statusSizeClasses[size],
            status === 'online' ? 'bg-online' : 'bg-offline'
          )}
        />
      )}
    </div>
  );
}
