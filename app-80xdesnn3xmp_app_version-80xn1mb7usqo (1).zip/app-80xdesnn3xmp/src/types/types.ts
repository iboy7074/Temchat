export type UserRole = 'user' | 'admin';
export type RoomType = 'direct' | 'group';
export type MessageType = 'text' | 'image' | 'file';

export interface Profile {
  id: string;
  username: string;
  email: string | null;
  avatar_url: string | null;
  status: string;
  bio: string | null;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export interface ChatRoom {
  id: string;
  name: string | null;
  type: RoomType;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface RoomMember {
  id: string;
  room_id: string;
  user_id: string;
  joined_at: string;
  last_read_at: string;
}

export interface Message {
  id: string;
  room_id: string;
  sender_id: string | null;
  content: string;
  type: MessageType;
  file_url: string | null;
  file_name: string | null;
  created_at: string;
}

export interface Mention {
  id: string;
  message_id: string;
  user_id: string;
  created_at: string;
}

export interface ChatRoomWithMembers extends ChatRoom {
  members?: Profile[];
  last_message?: Message;
  unread_count?: number;
}

export interface MessageWithSender extends Message {
  sender?: Profile;
  mentions?: Mention[];
}
